# include "../../s21_matrix.h"
# include "../s21_test.h"

START_TEST(test_one) {
    const int rows = rand() % 15 + 1;
    const int columns = rand() % 15 + 1;

    matrix_t matrix = {0};

    s21_create_matrix(rows, columns, &matrix);

    for (int i = 0; i < matrix.rows; ++i) {
        for (int j = 0; j < matrix.columns; ++j) {
            matrix.matrix[i][j] = 0;
            ck_assert_ldouble_eq_tol(0, matrix.matrix[i][j], 1e-07);
        }
    }

    ck_assert_int_eq(matrix.rows, rows);
    ck_assert_int_eq(matrix.columns, columns);
    s21_remove_matrix(&matrix);
}
END_TEST;

START_TEST(test_two) {


}
END_TEST;