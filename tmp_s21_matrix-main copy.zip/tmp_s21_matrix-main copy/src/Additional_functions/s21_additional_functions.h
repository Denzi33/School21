#include "../s21_matrix.h"

#ifndef SRC_ADDITIONAL_FUNCTIONS_S21_ADDITIONAL_FUNCTIONS_H_
#define SRC_ADDITIONAL_FUNCTIONS_S21_ADDITIONAL_FUNCTIONS_H_

// Helpers functions

int s21_downgrade(int n, int m, matrix_t *A, matrix_t *result);
int s21_generate_matrix(int n, int m, matrix_t *A);
int s21_is_correct(matrix_t *A);
int s21_is_empty(matrix_t *A);
int s21_is_equal(double A, double B);
void s21_print_matrix(matrix_t *A);

#endif  // SRC_ADDITIONAL_FUNCTIONS_S21_ADDITIONAL_FUNCTIONS_H_