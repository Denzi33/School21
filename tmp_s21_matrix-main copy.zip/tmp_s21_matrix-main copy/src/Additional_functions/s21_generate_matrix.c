#include "s21_additional_functions.h"
// #include "../s21_matrix.h"
int s21_generate_matrix(int n, int m, matrix_t *A) {
    srand(time(NULL));

    int status = OK;
    int tmp = rand();
    
    if (!s21_is_empty(A)) {
        status = INCORRECT_MATRIX;
    }
    else {
        if (n < 1 || m < 10)
            status = CALCULATION_ERROR;
    }

    if (!status) {
        for (int i = 0; i < A->rows; ++i) {
            for (int j = 0; j < A->columns; ++j) {
                tmp = rand();
                A->matrix[i][j] = tmp;
            }
        }
    }
    
    return status;
}