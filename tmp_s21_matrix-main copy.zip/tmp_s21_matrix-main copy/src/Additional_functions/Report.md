№) name_of_function - code_status/test_status

Helpers functions:
1) s21_downgrade - OK/?
2) s21_fill_matrix - OK/?
3) s21_is_correct - OK/?
4) s21_is_empty - OK/?
5) s21_is_equal - OK/?
6) s21_print_matrix - OK/?