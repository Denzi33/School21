№) name_of_function - code_status/test_status

1) s21_create_matrix - OK/?
2) s21_remove_matrix - OK/?
3) s21_eq_matrix - OK/?
4) s21_sum_matrix - OK/?
5) s21_sub_matrix - OK/?
6) s21_mult_number - OK/?
7) s21_mult_matrix - OK/?
8) s21_transpose - OK/?
9) s21_calc_complements - OK/?
10) s21_determinant - OK/?
11) s21_inverse_matrix - OK/?